/*
  compare_7methods.cpp
  ------------------------------------------------------------
  CPLEX 12.7 + Xcode 14.2 (clang++)
  Seven methods compared (lex objective with fixed U_min):
    (1) MIP-P
    (2) MIP-P + VI (VI1..VI5)
    (3) TwoStage(P) exact (master over z, subproblem MIP-P fixed-z)
    (4) TwoStage(P)+VI exact (master has VI3..VI5 + lazy feasibility cuts; subproblem has VI1..VI2)
    (5) MIP-T2
    (6) MIP-T2 + VI (VI3..VI5 + TI-safe tightening)
    (7) Heuristic AB improved (signed tardy build + pattern LS + tardy LS)

  Critical correctness points:
    - ALL methods enforce sum_j z_j == U_min  (NOT <=)
    - TwoStage is exhaustive enumeration of feasible z patterns.
    - No "value cuts" of eta(z) are used (NOT generally valid).
*/

#include <ilcplex/ilocplex.h>
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <numeric>
#include <random>
#include <sstream>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <thread>
ILOSTLBEGIN
using namespace std;

// ============================ Data structures ============================
struct Job {
    int id;
    int agent; // 0=A, 1=B
    int p;
    int d;
    int w;
};

struct SolveInfo {
    bool feasible = false;
    string status = "NA";
    double obj = -1.0;      // eta = |wTA - wTB|
    double time = 0.0;
    double gap = 0.0;
    double wTA = 0.0;
    double wTB = 0.0;
    vector<int> seq;
    vector<int> z;
    int iters = 0;
    int cuts = 0;
};

// ============================ Timing helpers ============================
static inline double nowSec() {
    using namespace chrono;
    return duration<double>(high_resolution_clock::now().time_since_epoch()).count();
}

static string statusToString(IloCplex& cplex) {
    IloAlgorithm::Status st = cplex.getStatus();
    switch (st) {
        case IloAlgorithm::Optimal: return "Optimal";
        case IloAlgorithm::Feasible: return "Feasible";
        case IloAlgorithm::Infeasible: return "Infeasible";
        case IloAlgorithm::Unbounded: return "Unbounded";
        case IloAlgorithm::InfeasibleOrUnbounded: return "InfOrUnb";
        case IloAlgorithm::Error: return "Error";
        default: return "Other";
    }
}

static double safeGap(IloCplex& cplex) {
    try {
        if (cplex.getStatus() == IloAlgorithm::Optimal) return 0.0;
        if (cplex.getStatus() == IloAlgorithm::Feasible) return cplex.getMIPRelativeGap();
    } catch (...) {}
    return 0.0;
}

// ============================ TF/RDD instance generation ============================
static vector<int> genProcessingTimes(int n, mt19937& rng) {
    uniform_int_distribution<int> p_dist(1, 100);
    vector<int> p(n);
    for (int i = 0; i < n; ++i) p[i] = p_dist(rng);
    return p;
}

static vector<int> genWeights(int n, mt19937& rng) {
    uniform_int_distribution<int> w_dist(1, 10);
    vector<int> w(n);
    for (int i = 0; i < n; ++i) w[i] = w_dist(rng);
    return w;
}

// Classical TF/RDD due date generator
// d_j ~ U[ P*(1-TF-RDD/2), P*(1-TF+RDD/2) ], clipped into [0, P]
static vector<int> genDueDates_TF_RDD(const vector<int>& p, double TF, double RDD, mt19937& rng) {
    int P = accumulate(p.begin(), p.end(), 0);
    double center = (double)P * (1.0 - TF);
    double half   = (double)P * (RDD / 2.0);
    int L = (int)floor(center - half);
    int U = (int)ceil(center + half);
    L = max(L, 0);
    U = min(U, P);
    if (L > U) swap(L, U);
    //[0, 0.5P]
   // L=0;
   // U=0.3*P;
    uniform_int_distribution<int> d_dist(L, U);

    vector<int> d(p.size());
    for (size_t i = 0; i < p.size(); ++i) d[i] = d_dist(rng);
    return d;
}

static vector<Job> generateInstance_TF_RDD(int n, int seed, double TF, double RDD) {
    mt19937 rng(seed);
    vector<int> p = genProcessingTimes(n, rng);
    vector<int> w = genWeights(n, rng);
    vector<int> d = genDueDates_TF_RDD(p, TF, RDD, rng);

    vector<Job> jobs;
    jobs.reserve(n);
    for (int i = 0; i < n; ++i) {
        Job jb;
        jb.id = i;
        jb.agent = (i < n/2) ? 0 : 1;
        //i<n/5
      //  jb.agent = (i < n/5) ? 0 : 1;
        jb.p = p[i];
        jb.d = d[i];
        jb.w = w[i];
        jobs.push_back(jb);
    }
    return jobs;
}

static void saveInstanceCSV(const string& path, const vector<Job>& jobs) {
    ofstream f(path.c_str());
    f << "ID,Agent,p,d,w\n";
    for (auto& jb : jobs) {
        f << jb.id << "," << jb.agent << "," << jb.p << "," << jb.d << "," << jb.w << "\n";
    }
}

// ============================ Evaluate a sequence ============================
static SolveInfo evalSequence(const vector<Job>& jobs, const vector<int>& seq) {
    int n = (int)jobs.size();
    vector<int> C(n, 0);
    int t = 0;
    for (int k = 0; k < n; k++) {
        int j = seq[k];
        t += jobs[j].p;
        C[j] = t;
    }
    int nA = 0, nB = 0;
    for (int j = 0; j < n; j++) (jobs[j].agent == 0 ? nA : nB)++;

    double sumA = 0.0, sumB = 0.0;
    vector<int> z(n, 0);
    for (int j = 0; j < n; j++) {
        int Tj = max(0, C[j] - jobs[j].d);
        if (C[j] > jobs[j].d) z[j] = 1;
        if (jobs[j].agent == 0) sumA += jobs[j].w * (double)Tj;
        else sumB += jobs[j].w * (double)Tj;
    }

    SolveInfo si;
    si.feasible = true;
    si.status = "SEQ";
    si.seq = seq;
    si.z = z;
    si.wTA = (nA ? sumA / nA : 0.0);
    si.wTB = (nB ? sumB / nB : 0.0);
    si.obj = fabs(si.wTA - si.wTB);
    return si;
}

// Moore algorithm for 1||sum Uj -> provides UB sequence and U_min
static void mooreDecompose(const vector<Job>& jobs, vector<int>& onTime, vector<int>& removed) {
    vector<int> idx(jobs.size());
    iota(idx.begin(), idx.end(), 0);
    sort(idx.begin(), idx.end(), [&](int a, int b) { return jobs[a].d < jobs[b].d; });

    onTime.clear();
    removed.clear();
    int t = 0;
    for (int j : idx) {
        onTime.push_back(j);
        t += jobs[j].p;
        if (t > jobs[j].d) {
            int arg = onTime[0];
            for (int u : onTime) if (jobs[u].p > jobs[arg].p) arg = u;
            removed.push_back(arg);
            t -= jobs[arg].p;
            onTime.erase(remove(onTime.begin(), onTime.end(), arg), onTime.end());
        }
    }
}

static pair<int, vector<int>> mooresAlgorithm(const vector<Job>& jobs) {
    vector<int> onTime, removed;
    mooreDecompose(jobs, onTime, removed);
    vector<int> seq;
    seq.insert(seq.end(), onTime.begin(), onTime.end());
    seq.insert(seq.end(), removed.begin(), removed.end());
    return make_pair((int)removed.size(), seq);
}

// ============================ Big-M data ============================
struct BigMData {
    int P = 0;
    double M = 0.0;
    vector<double> Mj;
    vector<int> alwaysOnTime; // d_j >= P => cannot be tardy
};

static BigMData computeBigM(const vector<Job>& jobs) {
    BigMData bm;
    int n = (int)jobs.size();
    bm.P = 0;
    int maxw = 0;
    for (int j = 0; j < n; j++) { bm.P += jobs[j].p; maxw = max(maxw, jobs[j].w); }
    bm.M = (double)bm.P;

    bm.Mj.assign(n, 0.0);
    bm.alwaysOnTime.assign(n, 0);
    for (int j = 0; j < n; j++) {
        if (jobs[j].d >= bm.P) {
            bm.alwaysOnTime[j] = 1;
            bm.Mj[j] = 0.0;
        } else {
            bm.alwaysOnTime[j] = 0;
            bm.Mj[j] = max(1.0, (double)bm.P - (double)jobs[j].d);
        }
    }
    return bm;
}

// Safe global upper bound on eta: maxw * P
static double computeEtaUpperBound(const vector<Job>& jobs) {
    int P = 0, maxw = 0;
    for (auto& jb : jobs) { P += jb.p; maxw = max(maxw, jb.w); }
    return (double)maxw * (double)P + 1.0;
}

// ============================ Shared modeling helpers ============================
static void addEtaConstraints(IloEnv& env, IloModel& model, const vector<Job>& jobs,
                              const IloNumVarArray& T, IloNumVar& eta)
{
    int n = (int)jobs.size();
    int nA = 0, nB = 0;
    for (int j = 0; j < n; j++) (jobs[j].agent == 0 ? nA : nB)++;

    IloExpr diff(env);
    for (int j = 0; j < n; j++) {
        double coeff = (jobs[j].agent == 0 ? (double)jobs[j].w / (double)nA : -(double)jobs[j].w / (double)nB);
        diff += coeff * T[j];
    }
    model.add(eta >= diff);
    model.add(eta >= -diff);
    diff.end();
}

static void extractSeqFromX(IloCplex& cplex, const IloArray<IloBoolVarArray>& x, vector<int>& seqOut) {
    int n = (int)seqOut.size();
    for (int k = 0; k < n; k++) {
        seqOut[k] = -1;
        for (int j = 0; j < n; j++) {
            if (cplex.getValue(x[j][k]) > 0.5) { seqOut[k] = j; break; }
        }
    }
}

// ============================ VI flags ============================
struct VIFlags {
    bool VI1_prefix_S_lb = true;        // S[k] >= sum of k smallest p
    bool VI2_sym_identical = true;      // identical jobs symmetry breaking
    bool VI3_edd_prefix_cover = true;   // global EDD prefix => at least 1 tardy
    bool VI4_capacity_deadlines = true; // sum p(1-z) <= D for jobs with d<=D
    bool VI5_pairwise = true;           // if two can't both be on-time => z_i+z_j>=1
};

static void addVI_MIP_P(IloEnv& env, IloModel& model, const vector<Job>& jobs,
                       const IloArray<IloBoolVarArray>& x, const IloNumVarArray& S,
                       const IloBoolVarArray& z, const VIFlags& f)
{
    int n = (int)jobs.size();

    if (f.VI1_prefix_S_lb) {
        vector<int> ps(n);
        for (int j = 0; j < n; j++) ps[j] = jobs[j].p;
        sort(ps.begin(), ps.end());
        int run = 0;
        for (int k = 0; k < n; k++) {
            run += ps[k];
            model.add(S[k] >= run);
        }
    }

    if (f.VI2_sym_identical) {
        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                if (jobs[i].agent == jobs[j].agent &&
                    jobs[i].p == jobs[j].p &&
                    jobs[i].d == jobs[j].d &&
                    jobs[i].w == jobs[j].w)
                {
                    IloExpr posi(env), posj(env);
                    for (int k = 0; k < n; k++) {
                        posi += (k + 1) * x[i][k];
                        posj += (k + 1) * x[j][k];
                    }
                    model.add(posi <= posj);
                    posi.end(); posj.end();
                }
            }
        }
    }

    // VI3..VI5 are constraints in z
    if (f.VI3_edd_prefix_cover) {
        vector<int> idx(n);
        iota(idx.begin(), idx.end(), 0);
        sort(idx.begin(), idx.end(), [&](int a, int b){ return jobs[a].d < jobs[b].d; });

        int sumP = 0;
        for (int r = 0; r < n; r++) {
            sumP += jobs[idx[r]].p;
            if (sumP > jobs[idx[r]].d) {
                IloExpr cover(env);
                for (int i = 0; i <= r; i++) cover += z[idx[i]];
                model.add(cover >= 1);
                cover.end();
            }
        }
    }

    if (f.VI4_capacity_deadlines) {
        vector<int> Ds;
        Ds.reserve(n);
        for (int j = 0; j < n; j++) Ds.push_back(jobs[j].d);
        sort(Ds.begin(), Ds.end());
        Ds.erase(unique(Ds.begin(), Ds.end()), Ds.end());

        for (int D : Ds) {
            IloExpr cap(env);
            for (int j = 0; j < n; j++) if (jobs[j].d <= D) cap += jobs[j].p * (1 - z[j]);
            model.add(cap <= D);
            cap.end();
        }
    }

    if (f.VI5_pairwise) {
        for (int i = 0; i < n; i++) for (int j = i+1; j < n; j++) {
            if (jobs[i].p + jobs[j].p > max(jobs[i].d, jobs[j].d)) model.add(z[i] + z[j] >= 1);
        }
    }
}

static void addVI_Zonly(IloEnv& env, IloModel& model, const vector<Job>& jobs, const IloBoolVarArray& z, const VIFlags& f) {
    int n = (int)jobs.size();

    if (f.VI3_edd_prefix_cover) {
        vector<int> idx(n);
        iota(idx.begin(), idx.end(), 0);
        sort(idx.begin(), idx.end(), [&](int a, int b){ return jobs[a].d < jobs[b].d; });

        int sumP = 0;
        for (int r = 0; r < n; r++) {
            sumP += jobs[idx[r]].p;
            if (sumP > jobs[idx[r]].d) {
                IloExpr cover(env);
                for (int i = 0; i <= r; i++) cover += z[idx[i]];
                model.add(cover >= 1);
                cover.end();
            }
        }
    }

    if (f.VI4_capacity_deadlines) {
        vector<int> Ds;
        Ds.reserve(n);
        for (int j = 0; j < n; j++) Ds.push_back(jobs[j].d);
        sort(Ds.begin(), Ds.end());
        Ds.erase(unique(Ds.begin(), Ds.end()), Ds.end());

        for (int D : Ds) {
            IloExpr cap(env);
            for (int j = 0; j < n; j++) if (jobs[j].d <= D) cap += jobs[j].p * (1 - z[j]);
            model.add(cap <= D);
            cap.end();
        }
    }

    if (f.VI5_pairwise) {
        for (int i = 0; i < n; i++) for (int j = i+1; j < n; j++) {
            if (jobs[i].p + jobs[j].p > max(jobs[i].d, jobs[j].d)) model.add(z[i] + z[j] >= 1);
        }
    }
}

// ============================ Feasibility cuts (EDD prefix within on-time set) ============================
struct CutPrefix {
    int type = 1;
    vector<int> P;
    vector<int> Q; // for type2
    int mP = 1;
    int Delta = 0;
};

static bool findViolatedPrefixWithinOnTime(const vector<Job>& jobs, const vector<int>& b, CutPrefix& cutOut) {
    vector<int> S;
    int n = (int)jobs.size();
    for (int j = 0; j < n; j++) if (b[j] == 0) S.push_back(j);
    sort(S.begin(), S.end(), [&](int a, int c){ return jobs[a].d < jobs[c].d; });

    int sumP = 0;
    int dmax = 0;
    vector<int> prefix;
    for (size_t r = 0; r < S.size(); r++) {
        int j = S[r];
        prefix.push_back(j);
        sumP += jobs[j].p;
        dmax = max(dmax, jobs[j].d);
        if (sumP > dmax) {
            cutOut.P = prefix;
            cutOut.Delta = sumP - dmax;

            // Q = argmax p
            int pmax = -1;
            cutOut.Q.clear();
            for (size_t t = 0; t < prefix.size(); t++) {
                int jj = prefix[t];
                if (jobs[jj].p > pmax) { pmax = jobs[jj].p; cutOut.Q.clear(); cutOut.Q.push_back(jj); }
                else if (jobs[jj].p == pmax) cutOut.Q.push_back(jj);
            }

            vector<int> ps;
            for (int jj : prefix) ps.push_back(jobs[jj].p);
            sort(ps.begin(), ps.end(), greater<int>());
            int removed = 0, remSum = sumP;
            while (removed < (int)ps.size() && remSum > dmax) { remSum -= ps[removed]; removed++; }
            cutOut.mP = max(1, removed);
            return true;
        }
    }
    return false;
}

// ============================ Method 1: MIP-P ============================
static void addAssignmentAndCumulativeS(IloEnv& env, IloModel& model, const vector<Job>& jobs,
                                       IloArray<IloBoolVarArray>& x, IloNumVarArray& S)
{
    int n = (int)jobs.size();

    for (int k = 0; k < n; k++) {
        IloExpr sum(env);
        for (int j = 0; j < n; j++) sum += x[j][k];
        model.add(sum == 1);
        sum.end();
    }
    for (int j = 0; j < n; j++) {
        IloExpr sum(env);
        for (int k = 0; k < n; k++) sum += x[j][k];
        model.add(sum == 1);
        sum.end();
    }

    {
        IloExpr s0(env);
        for (int j = 0; j < n; j++) s0 += jobs[j].p * x[j][0];
        model.add(S[0] == s0);
        s0.end();
    }
    for (int k = 1; k < n; k++) {
        IloExpr sk(env);
        for (int j = 0; j < n; j++) sk += jobs[j].p * x[j][k];
        model.add(S[k] == S[k - 1] + sk);
        sk.end();
    }
}

static void linkCompletionTimes(IloEnv& env, IloModel& model, const vector<Job>& jobs,
                               IloArray<IloBoolVarArray>& x, const IloNumVarArray& S,
                               IloNumVarArray& C, double M)
{
    int n = (int)jobs.size();
    for (int j = 0; j < n; j++) {
        for (int k = 0; k < n; k++) {
            model.add(C[j] >= S[k] - M * (1 - x[j][k]));
            model.add(C[j] <= S[k] + M * (1 - x[j][k]));
        }
    }
}

static void addTardinessLogic(IloEnv& env, IloModel& model, const vector<Job>& jobs,
                             const BigMData& bm,
                             IloNumVarArray& C, IloNumVarArray& T, IloBoolVarArray& z)
{
    int n = (int)jobs.size();
    double eps = 1e-6;
    for (int j = 0; j < n; j++) {
        if (bm.alwaysOnTime[j]) {
            model.add(z[j] == 0);
            model.add(T[j] == 0);
            model.add(C[j] <= jobs[j].d);
        } else {
            model.add(T[j] >= C[j] - jobs[j].d);
            model.add(T[j] >= 0);
            model.add(T[j] <= (C[j] - jobs[j].d) + bm.M * (1 - z[j]));
            model.add(T[j] <= bm.M * z[j]);
            model.add(C[j] <= jobs[j].d + bm.M * z[j]);
            model.add(C[j] >= jobs[j].d - bm.M * (1 - z[j]));
            model.add(C[j] >= jobs[j].d + eps - bm.M * (1 - z[j]));
        }
    }
}

static SolveInfo solveMIP_P(const vector<Job>& jobs, int U_min, double UB_eta, double timeLimit, bool useVI)
{
    SolveInfo out;
    double t0 = nowSec();
    int n = (int)jobs.size();
    BigMData bm = computeBigM(jobs);

    int mustOnTime = 0;
    for (int j = 0; j < n; j++) if (bm.alwaysOnTime[j]) mustOnTime++;
    if (U_min > n - mustOnTime) {
        out.feasible = false;
        out.status = "PreInfeasible(U_min too large)";
        out.time = nowSec() - t0;
        return out;
    }

    try {
        IloEnv env;
        IloModel model(env);

        IloArray<IloBoolVarArray> x(env, n);
        for (int j = 0; j < n; j++) x[j] = IloBoolVarArray(env, n);

        IloNumVarArray S(env, n, 0.0, IloInfinity);
        IloNumVarArray C(env, n, 0.0, IloInfinity);
        IloNumVarArray T(env, n, 0.0, IloInfinity);
        IloBoolVarArray z(env, n);
        IloNumVar eta(env, 0.0, IloInfinity);

        model.add(IloMinimize(env, eta));

        addAssignmentAndCumulativeS(env, model, jobs, x, S);
        linkCompletionTimes(env, model, jobs, x, S, C, bm.M);
        addTardinessLogic(env, model, jobs, bm, C, T, z);

        {
            IloExpr sumz(env);
            for (int j = 0; j < n; j++) sumz += z[j];
            model.add(sumz == U_min);
            sumz.end();
        }

        addEtaConstraints(env, model, jobs, T, eta);

        if (UB_eta < 1e100) model.add(eta <= UB_eta + 1e-6);

        if (useVI) {
            VIFlags f;
            addVI_MIP_P(env, model, jobs, x, S, z, f);
        }

        IloCplex cplex(model);
        cplex.setParam(IloCplex::Param::TimeLimit, timeLimit);
        cplex.setParam(IloCplex::Param::Threads, 1);
      //  cplex.setParam(IloCplex::Param::MIP::Display, 0);
      //  cplex.setOut(env.getNullStream());

        bool ok = cplex.solve();
        out.time = nowSec() - t0;
        out.status = ok ? statusToString(cplex) : "NoSolve";
        out.gap = ok ? safeGap(cplex) : 0.0;

        if (ok && (cplex.getStatus() == IloAlgorithm::Optimal || cplex.getStatus() == IloAlgorithm::Feasible)) {
            out.feasible = true;
            out.obj = cplex.getValue(eta);

            out.seq.assign(n, -1);
            extractSeqFromX(cplex, x, out.seq);

            out.z.assign(n, 0);
            for (int j = 0; j < n; j++) out.z[j] = (cplex.getValue(z[j]) > 0.5 ? 1 : 0);

            SolveInfo ev = evalSequence(jobs, out.seq);
            out.wTA = ev.wTA; out.wTB = ev.wTB;
            out.obj = ev.obj;
        }

        env.end();
    } catch (IloException& e) {
        out.time = nowSec() - t0;
        out.status = "Exception";
        out.feasible = false;
        cerr << "MIP-P exception: " << e << "\n";
    }
    return out;
}

// ============================ Fixed-z subproblem (exact sequencing with z fixed) ============================
static SolveInfo solveSubproblem_MIP_P_fixedZ(const vector<Job>& jobs, const vector<int>& b,
                                             double UB_eta, double timeLimit,
                                             bool useVI12)
{
    SolveInfo out;
    double t0 = nowSec();
    int n = (int)jobs.size();
    BigMData bm = computeBigM(jobs);
    double eps = 1e-6;

    try {
        IloEnv env;
        IloModel model(env);

        IloArray<IloBoolVarArray> x(env, n);
        for (int j = 0; j < n; j++) x[j] = IloBoolVarArray(env, n);

        IloNumVarArray S(env, n, 0.0, IloInfinity);
        IloNumVarArray C(env, n, 0.0, IloInfinity);
        IloNumVarArray T(env, n, 0.0, IloInfinity);
        IloNumVar eta(env, 0.0, IloInfinity);

        model.add(IloMinimize(env, eta));

        addAssignmentAndCumulativeS(env, model, jobs, x, S);
        linkCompletionTimes(env, model, jobs, x, S, C, bm.M);

        for (int j = 0; j < n; j++) {
            if (bm.alwaysOnTime[j]) {
                if (b[j] == 1) {
                    IloNumVar dummy(env, 0.0, 1.0);
                    model.add(dummy >= 2.0);
                } else {
                    model.add(T[j] == 0);
                    model.add(C[j] <= jobs[j].d);
                }
            } else {
                if (b[j] == 0) {
                    model.add(T[j] == 0);
                    model.add(C[j] <= jobs[j].d);
                } else {
                    model.add(C[j] >= jobs[j].d + eps);
                    model.add(T[j] >= C[j] - jobs[j].d);
                    model.add(T[j] <= C[j] - jobs[j].d);
                    model.add(T[j] <= bm.Mj[j]);
                }
            }
        }

        addEtaConstraints(env, model, jobs, T, eta);
        if (UB_eta < 1e100) model.add(eta <= UB_eta + 1e-6);

        if (useVI12) {
            VIFlags f;
            f.VI3_edd_prefix_cover = false;
            f.VI4_capacity_deadlines = false;
            f.VI5_pairwise = false;
            IloBoolVarArray zDummy(env, n);
            addVI_MIP_P(env, model, jobs, x, S, zDummy, f);
        }

        IloCplex cplex(model);
        cplex.setParam(IloCplex::Param::TimeLimit, timeLimit);
        cplex.setParam(IloCplex::Param::Threads, 1);
        cplex.setParam(IloCplex::Param::MIP::Display, 0);
        cplex.setOut(env.getNullStream());

        bool ok = cplex.solve();
        out.time = nowSec() - t0;
        out.status = ok ? statusToString(cplex) : "NoSolve";
        out.gap = ok ? safeGap(cplex) : 0.0;

        if (ok && (cplex.getStatus() == IloAlgorithm::Optimal || cplex.getStatus() == IloAlgorithm::Feasible)) {
            out.feasible = true;
            out.obj = cplex.getValue(eta);
            out.seq.assign(n, -1);
            extractSeqFromX(cplex, x, out.seq);
            out.z = b;

            SolveInfo ev = evalSequence(jobs, out.seq);
            out.wTA = ev.wTA; out.wTB = ev.wTB;
            out.obj = ev.obj;
        }

        env.end();
    } catch (IloException& e) {
        out.time = nowSec() - t0;
        out.status = "Exception";
        out.feasible = false;
        cerr << "Fixed-z subproblem exception: " << e << "\n";
    }
    return out;
}

// ============================ Methods 3-4: TwoStage exact enumeration ============================
static void addNoGoodCutsToMaster(IloEnv& env, IloModel& master, const IloBoolVarArray& z,
                                 const vector<vector<int>>& visited)
{
    int n = (int)z.getSize();
    for (auto& pat : visited) {
        IloExpr diff(env);
        for (int j = 0; j < n; j++) diff += (pat[j] == 1) ? (1 - z[j]) : z[j];
        master.add(diff >= 1);
        diff.end();
    }
}

static void addDynamicFeasCutsToMaster(IloEnv& env, IloModel& master, const vector<Job>& jobs,
                                      const IloBoolVarArray& z,
                                      const vector<CutPrefix>& cuts)
{
    for (size_t c = 0; c < cuts.size(); c++) {
        const CutPrefix& cp = cuts[c];
        if (cp.type == 1) {
            IloExpr e(env);
            for (size_t t = 0; t < cp.P.size(); t++) e += z[cp.P[t]];
            master.add(e >= 1);
            e.end();
        } else if (cp.type == 2) {
            IloExpr e(env);
            for (size_t t = 0; t < cp.Q.size(); t++) e += z[cp.Q[t]];
            master.add(e >= 1);
            e.end();
        } else if (cp.type == 3) {
            IloExpr e(env);
            for (size_t t = 0; t < cp.P.size(); t++) e += z[cp.P[t]];
            master.add(e >= cp.mP);
            e.end();
        } else if (cp.type == 4) {
            IloExpr e(env);
            for (size_t t = 0; t < cp.P.size(); t++) e += jobs[cp.P[t]].p * z[cp.P[t]];
            master.add(e >= cp.Delta);
            e.end();
        }
    }
}

static SolveInfo runTwoStageP_exact(const vector<Job>& jobs, int U_min, double UB_eta,
                                   double timeLimitTotal, bool useVIinMaster, bool useVI12inSub)
{
    SolveInfo best;
    double tStart = nowSec();
    int n = (int)jobs.size();

    auto mo = mooresAlgorithm(jobs);
    SolveInfo inc = evalSequence(jobs, mo.second);
    best = inc;
    best.status = "Incumbent(Moore)";

    vector<vector<int>> visitedZ;
    vector<CutPrefix> dynCuts;
    int iters = 0;

    while (true) {
        double elapsed = nowSec() - tStart;
        if (elapsed >= timeLimitTotal) {
            best.time = elapsed;
            best.iters = iters;
            best.status = "TimeLimit";
            return best;
        }

        IloEnv env;
        IloModel master(env);
        IloBoolVarArray z(env, n);
        master.add(IloMinimize(env, 0));

        {
            IloExpr sumz(env);
            for (int j = 0; j < n; j++) sumz += z[j];
            master.add(sumz == U_min);
            sumz.end();
        }
        
        BigMData bm = computeBigM(jobs);
        for (int j = 0; j < n; j++) if (bm.alwaysOnTime[j]) master.add(z[j] == 0);

        if (useVIinMaster) {
            VIFlags vf;
            vf.VI1_prefix_S_lb = false;
            vf.VI2_sym_identical = false;
            addVI_Zonly(env, master, jobs, z, vf);
        }

        addDynamicFeasCutsToMaster(env, master, jobs, z, dynCuts);

        if (!visitedZ.empty()) addNoGoodCutsToMaster(env, master, z, visitedZ);

        IloCplex cplex(master);
        cplex.setParam(IloCplex::Param::Threads, 1);
        cplex.setParam(IloCplex::Param::MIP::Display, 0);
        cplex.setOut(env.getNullStream());

        double remain = max(1.0, timeLimitTotal - elapsed);
        cplex.setParam(IloCplex::Param::TimeLimit, remain);

        bool ok = cplex.solve();
        iters++;

        if (!ok || !(cplex.getStatus() == IloAlgorithm::Optimal || cplex.getStatus() == IloAlgorithm::Feasible)) {
            best.time = nowSec() - tStart;
            best.iters = iters;
            best.cuts = (int)dynCuts.size() + (int)visitedZ.size();
            best.status = "MasterExhausted(NoSolve)";
            env.end();
            return best;
        }

        vector<int> b(n, 0);
        for (int j = 0; j < n; j++) b[j] = (cplex.getValue(z[j]) > 0.5 ? 1 : 0);
        visitedZ.push_back(b);
        env.end();

        double elapsed2 = nowSec() - tStart;
        double remain2 = max(1.0, timeLimitTotal - elapsed2);
        SolveInfo sub = solveSubproblem_MIP_P_fixedZ(jobs, b, best.obj, remain2, useVI12inSub);
        
        if (best.obj==0) //reach the lower bound
            break;
        
        if (sub.feasible) {
            if (sub.obj < best.obj - 1e-9) {
                best = sub;
                best.status = "TwoStage(P) best";
            }
        } else {
            CutPrefix cp;
            if (findViolatedPrefixWithinOnTime(jobs, b, cp)) {
                CutPrefix c1 = cp; c1.type = 1; dynCuts.push_back(c1);
                CutPrefix c3 = cp; c3.type = 3; dynCuts.push_back(c3);
                CutPrefix c4 = cp; c4.type = 4; dynCuts.push_back(c4);
            }
        }
    }
}

// ============================ Methods 5-6: MIP-T2 (time-indexed) ============================
static SolveInfo solveMIP_T2(const vector<Job>& jobs, int U_min, double UB_eta, double timeLimit, bool useVI)
{
    SolveInfo out;
    double t0 = nowSec();
    int n = (int)jobs.size();
    BigMData bm = computeBigM(jobs);
    int T_hor = bm.P;
    double eps = 1e-6;

    try {
        IloEnv env;
        IloModel model(env);

        IloBoolVarArray z(env, n);
        IloNumVar eta(env, 0.0, IloInfinity);

        vector<IloBoolVarArray> y(n);
        for (int j = 0; j < n; j++) {
            int L = T_hor - jobs[j].p + 1;
            y[j] = IloBoolVarArray(env, L);
        }

        model.add(IloMinimize(env, eta));

        for (int j = 0; j < n; j++) {
            IloExpr s(env);
            for (int t = 0; t < y[j].getSize(); t++) s += y[j][t];
            model.add(s == 1);
            s.end();
        }

        for (int tau = 1; tau <= T_hor; tau++) {
            IloExpr cap(env);
            for (int j = 0; j < n; j++) {
                int pj = jobs[j].p;
                for (int t = 0; t < y[j].getSize(); t++) {
                    int start = t + 1;
                    int end = t + pj;
                    if (start <= tau && tau <= end) cap += y[j][t];
                }
            }
            model.add(cap <= 1);
            cap.end();
        }

        IloNumVarArray C(env, n, 0.0, (double)T_hor);
        for (int j = 0; j < n; j++) {
            IloExpr cj(env);
            for (int t = 0; t < y[j].getSize(); t++) {
                int comp = (t + jobs[j].p);
                cj += comp * y[j][t];
            }
            model.add(C[j] == cj);
            cj.end();
        }

        IloNumVarArray Td(env, n, 0.0, IloInfinity);
        for (int j = 0; j < n; j++) {
            if (bm.alwaysOnTime[j]) {
                model.add(z[j] == 0);
                model.add(Td[j] == 0);
                model.add(C[j] <= jobs[j].d);
            } else {
                model.add(Td[j] >= C[j] - jobs[j].d);
                model.add(Td[j] >= 0);
                model.add(Td[j] <= (C[j] - jobs[j].d) + bm.M * (1 - z[j]));
                model.add(Td[j] <= bm.M * z[j]);
                model.add(C[j] <= jobs[j].d + bm.M * z[j]);
                model.add(C[j] >= jobs[j].d - bm.M * (1 - z[j]));
                model.add(C[j] >= jobs[j].d + eps - bm.M * (1 - z[j]));
            }
        }

        addEtaConstraints(env, model, jobs, Td, eta);

        {
            IloExpr sumz(env);
            for (int j = 0; j < n; j++) sumz += z[j];
            model.add(sumz == U_min);
            sumz.end();
        }
        if (UB_eta < 1e100) model.add(eta <= UB_eta + 1e-6);

        if (useVI) {
            VIFlags vf;
            vf.VI1_prefix_S_lb = false;
            vf.VI2_sym_identical = false;
            addVI_Zonly(env, model, jobs, z, vf);

            for (int j = 0; j < n; j++) {
                for (int t = 0; t < y[j].getSize(); t++) {
                    int comp = (t + jobs[j].p);
                    if (comp <= jobs[j].d) {
                        model.add(y[j][t] <= 1 - z[j]);
                    }
                    if (comp >= jobs[j].d + eps) {
                        model.add(y[j][t] <= z[j]);
                    }
                }
            }
        }

        IloCplex cplex(model);
        cplex.setParam(IloCplex::Param::TimeLimit, timeLimit);
        cplex.setParam(IloCplex::Param::Threads, 1);
        cplex.setParam(IloCplex::Param::MIP::Display, 0);
        cplex.setOut(env.getNullStream());

        bool ok = cplex.solve();
        out.time = nowSec() - t0;
        out.status = ok ? statusToString(cplex) : "NoSolve";
        out.gap = ok ? safeGap(cplex) : 0.0;

        if (ok && (cplex.getStatus() == IloAlgorithm::Optimal || cplex.getStatus() == IloAlgorithm::Feasible)) {
            out.feasible = true;
            out.obj = cplex.getValue(eta);
            out.z.assign(n, 0);
            for (int j = 0; j < n; j++) out.z[j] = (cplex.getValue(z[j]) > 0.5 ? 1 : 0);
        }

        env.end();
    } catch (IloException& e) {
        out.time = nowSec() - t0;
        out.status = "Exception";
        out.feasible = false;
        cerr << "MIP-T2 exception: " << e << "\n";
    }
    return out;
}

static bool buildSeq_BlockRepair(const vector<Job>& jobs, const vector<int>& b, vector<int>& seqOut);

static int countTardy(const vector<int>& z) {
    return accumulate(z.begin(), z.end(), 0);
}

static vector<int> makeFixedUminPatternFromReferenceSeq(const vector<Job>& jobs,
                                                        const vector<int>& refSeq,
                                                        int U_min) {
    int n = (int)jobs.size();
    BigMData bm = computeBigM(jobs);
    SolveInfo ref = evalSequence(jobs, refSeq);
    vector<int> b = ref.z;

    for (int j = 0; j < n; ++j) if (bm.alwaysOnTime[j]) b[j] = 0;
    if (countTardy(b) == U_min) return b;

    vector<int> C(n, 0);
    int t = 0;
    for (int k = 0; k < n; ++k) {
        int j = refSeq[k];
        t += jobs[j].p;
        C[j] = t;
    }

    vector<int> cand;
    cand.reserve(n);
    for (int j = 0; j < n; ++j) if (!bm.alwaysOnTime[j]) cand.push_back(j);

    sort(cand.begin(), cand.end(), [&](int a, int c) {
        int la = C[a] - jobs[a].d;
        int lc = C[c] - jobs[c].d;
        if (la != lc) return la > lc;
        double ra = (double)jobs[a].w / (double)max(1, jobs[a].p);
        double rc = (double)jobs[c].w / (double)max(1, jobs[c].p);
        if (fabs(ra - rc) > 1e-12) return ra > rc;
        if (jobs[a].d != jobs[c].d) return jobs[a].d < jobs[c].d;
        return a < c;
    });

    b.assign(n, 0);
    for (int i = 0; i < U_min && i < (int)cand.size(); ++i) b[cand[i]] = 1;
    return b;
}

static bool finalizeTwoBlockSequence(const vector<Job>& jobs,
                                     const vector<int>& b,
                                     const vector<int>& onTime,
                                     const vector<int>& tardy,
                                     vector<int>& seqOut) {
    int n = (int)jobs.size();
    seqOut.clear();
    seqOut.insert(seqOut.end(), onTime.begin(), onTime.end());
    int startTardy = (int)seqOut.size();
    seqOut.insert(seqOut.end(), tardy.begin(), tardy.end());

    if ((int)seqOut.size() != n) return false;

    vector<int> C(n, 0);
    auto recompute = [&]() {
        int t = 0;
        for (int k = 0; k < n; ++k) {
            int j = seqOut[k];
            t += jobs[j].p;
            C[j] = t;
        }
    };
    recompute();

    for (int k = 0; k < startTardy; ++k) {
        int j = seqOut[k];
        if (C[j] > jobs[j].d) return false;
    }

    bool changed = true;
    int safety = 0;
    while (changed && safety++ < n * n) {
        changed = false;
        recompute();
        for (int k = startTardy; k < n; ++k) {
            int j = seqOut[k];
            if (b[j] == 1 && C[j] <= jobs[j].d) {
                if (k == n - 1) return false;
                swap(seqOut[k], seqOut[k + 1]);
                changed = true;
                break;
            }
        }
    }

    int t = 0;
    for (int k = 0; k < n; ++k) {
        int j = seqOut[k];
        t += jobs[j].p;
        if (b[j] == 0 && t > jobs[j].d) return false;
        if (b[j] == 1 && t <= jobs[j].d) return false;
    }
    return true;
}

static bool buildSeq_MooreBasedRule(const vector<Job>& jobs,
                                    const vector<int>& b,
                                    const vector<int>& removedOrder,
                                    vector<int>& seqOut) {
    int n = (int)jobs.size();
    vector<int> onTime, tardy;
    onTime.reserve(n);
    tardy.reserve(n);
    for (int j = 0; j < n; ++j) {
        if (b[j] == 0) onTime.push_back(j);
        else tardy.push_back(j);
    }

    sort(onTime.begin(), onTime.end(), [&](int a, int c) {
        if (jobs[a].d != jobs[c].d) return jobs[a].d < jobs[c].d;
        return a < c;
    });

    vector<int> tardyOrdered;
    tardyOrdered.reserve(tardy.size());
    vector<int> used(n, 0);
    for (int j : removedOrder) {
        if (b[j] == 1 && !used[j]) {
            tardyOrdered.push_back(j);
            used[j] = 1;
        }
    }
    vector<int> extra;
    for (int j : tardy) if (!used[j]) extra.push_back(j);
    sort(extra.begin(), extra.end(), [&](int a, int c) {
        if (jobs[a].d != jobs[c].d) return jobs[a].d < jobs[c].d;
        return a < c;
    });
    tardyOrdered.insert(tardyOrdered.end(), extra.begin(), extra.end());

    return finalizeTwoBlockSequence(jobs, b, onTime, tardyOrdered, seqOut);
}

static bool buildSeq_WeightedDispatchRule(const vector<Job>& jobs,
                                          const vector<int>& b,
                                          vector<int>& seqOut) {
    int n = (int)jobs.size();
    vector<int> onTime, tardy;
    onTime.reserve(n);
    tardy.reserve(n);
    for (int j = 0; j < n; ++j) {
        if (b[j] == 0) onTime.push_back(j);
        else tardy.push_back(j);
    }

    sort(onTime.begin(), onTime.end(), [&](int a, int c) {
        if (jobs[a].d != jobs[c].d) return jobs[a].d < jobs[c].d;
        return a < c;
    });

    sort(tardy.begin(), tardy.end(), [&](int a, int c) {
        double ra = (double)jobs[a].w / (double)max(1, jobs[a].p);
        double rc = (double)jobs[c].w / (double)max(1, jobs[c].p);
        if (fabs(ra - rc) > 1e-12) return ra > rc;
        if (jobs[a].d != jobs[c].d) return jobs[a].d < jobs[c].d;
        if (jobs[a].w != jobs[c].w) return jobs[a].w > jobs[c].w;
        if (jobs[a].p != jobs[c].p) return jobs[a].p < jobs[c].p;
        return a < c;
    });

    return finalizeTwoBlockSequence(jobs, b, onTime, tardy, seqOut);
}

static SolveInfo runMooreBasedConstructive(const vector<Job>& jobs, int U_min) {
    double t0 = nowSec();
    vector<int> onTime, removed;
    mooreDecompose(jobs, onTime, removed);
    vector<int> moSeq;
    moSeq.insert(moSeq.end(), onTime.begin(), onTime.end());
    moSeq.insert(moSeq.end(), removed.begin(), removed.end());

    vector<int> b = makeFixedUminPatternFromReferenceSeq(jobs, moSeq, U_min);
    vector<int> seq;
    bool ok = buildSeq_MooreBasedRule(jobs, b, removed, seq);
    if (!ok) ok = buildSeq_BlockRepair(jobs, b, seq);

    SolveInfo out;
    out.time = nowSec() - t0;
    if (!ok) {
        out.status = "MooreConstruct-Fail";
        out.feasible = false;
        return out;
    }
    out = evalSequence(jobs, seq);
    out.z = b;
    out.seq = seq;
    out.status = "MooreConstruct";
    out.time = nowSec() - t0;
    return out;
}

static SolveInfo runEDDConstructive(const vector<Job>& jobs, int U_min) {
    double t0 = nowSec();
    auto mo = mooresAlgorithm(jobs);
    vector<int> b = makeFixedUminPatternFromReferenceSeq(jobs, mo.second, U_min);
    vector<int> seq;
    SolveInfo out;
    bool ok = buildSeq_BlockRepair(jobs, b, seq);
    out.time = nowSec() - t0;
    if (!ok) {
        out.status = "EDDConstruct-Fail";
        out.feasible = false;
        return out;
    }
    out = evalSequence(jobs, seq);
    out.z = b;
    out.seq = seq;
    out.status = "EDDConstruct";
    out.time = nowSec() - t0;
    return out;
}

static SolveInfo runWeightedDispatchConstructive(const vector<Job>& jobs, int U_min) {
    double t0 = nowSec();
    auto mo = mooresAlgorithm(jobs);
    vector<int> b = makeFixedUminPatternFromReferenceSeq(jobs, mo.second, U_min);
    vector<int> seq;
    SolveInfo out;
    bool ok = buildSeq_WeightedDispatchRule(jobs, b, seq);
    if (!ok) ok = buildSeq_BlockRepair(jobs, b, seq);
    out.time = nowSec() - t0;
    if (!ok) {
        out.status = "WTDispatch-Fail";
        out.feasible = false;
        return out;
    }
    out = evalSequence(jobs, seq);
    out.z = b;
    out.seq = seq;
    out.status = "WTDispatch";
    out.time = nowSec() - t0;
    return out;
}

// ============================ Heuristic AB Improved (Method 7) ============================
// Helper functions for Heuristic AB
static inline string packBitsKey(const vector<int>& z01) {
    const int n = (int)z01.size();
    const int nBytes = (n + 7) / 8;
    string key(nBytes, '\0');
    for (int i = 0; i < n; ++i) {
        if (z01[i]) key[i >> 3] = (char)( key[i >> 3] | (char)(1u << (i & 7)) );
    }
    return key;
}

static inline vector<int> unpackBitsKey(const string& key, int n) {
    vector<int> z(n, 0);
    for (int i = 0; i < n; ++i) {
        unsigned char byte = (unsigned char)key[i >> 3];
        z[i] = ((byte >> (i & 7)) & 1u) ? 1 : 0;
    }
    return z;
}

static inline IloExpr buildHamExpr(IloEnv env, const IloBoolVarArray& z, const vector<int>& b) {
    const int n = (int)b.size();
    IloExpr ham(env);
    for (int j = 0; j < n; ++j) ham += (b[j] == 1) ? (1 - z[j]) : z[j];
    return ham;
}

// Robust constructor (on-time EDD, tardy EDD, then push any accidental on-time tardy to the right)
static bool buildSeq_BlockRepair(const vector<Job>& jobs, const vector<int>& b, vector<int>& seqOut) {
    int n = (int)jobs.size();
    BigMData bm = computeBigM(jobs);

    vector<int> S0, S1;
    S0.reserve(n); S1.reserve(n);
    for (int j = 0; j < n; ++j) {
        if (b[j] == 0) S0.push_back(j);
        else {
            if (bm.alwaysOnTime[j]) return false;
            S1.push_back(j);
        }
    }

    sort(S0.begin(), S0.end(), [&](int a, int c){ return jobs[a].d < jobs[c].d; });
    sort(S1.begin(), S1.end(), [&](int a, int c){ return jobs[a].d < jobs[c].d; });
    return finalizeTwoBlockSequence(jobs, b, S0, S1, seqOut);
}

// Improved tardy-order constructor for heuristic: signed-greedy for tardy block
static bool buildSeq_HeurSignedTardy(const vector<Job>& jobs, const vector<int>& b, vector<int>& seqOut) {
    int n = (int)jobs.size();
    BigMData bm = computeBigM(jobs);

    int nA=0,nB=0;
    for(int j=0;j<n;j++) (jobs[j].agent==0? nA:nB)++;

    auto coeff = [&](int j)->double{
        if (jobs[j].agent==0) return (double)jobs[j].w/(double)nA;
        return -(double)jobs[j].w/(double)nB;
    };

    vector<int> onTime, tardy;
    onTime.reserve(n); tardy.reserve(n);
    for(int j=0;j<n;j++){
        if(b[j]==0) onTime.push_back(j);
        else {
            if (bm.alwaysOnTime[j]) return false;
            tardy.push_back(j);
        }
    }

    sort(onTime.begin(), onTime.end(), [&](int a,int c){ return jobs[a].d < jobs[c].d; });

    int t=0;
    for(int j: onTime){
        t += jobs[j].p;
        if (t > jobs[j].d) return false;
    }
    int t0 = t;

    vector<int> rem = tardy;
    vector<int> order;
    order.reserve(rem.size());

    double diff = 0.0;
    int curT = t0;

    int guard = 0;
    while(!rem.empty() && guard++ < n*n){
        int bestIdx = -1;
        double bestScore = 1e100;

        for(int i=0;i<(int)rem.size();i++){
            int j = rem[i];
            int Cj = curT + jobs[j].p;
            if (Cj <= jobs[j].d) continue;
            double contrib = coeff(j) * ((double)Cj - (double)jobs[j].d);
            double score = fabs((diff + contrib));
            score += 1e-9 * (-fabs(coeff(j)) * (double)jobs[j].p);
            if (score < bestScore){
                bestScore = score;
                bestIdx = i;
            }
        }

        if (bestIdx == -1) {
            return buildSeq_BlockRepair(jobs, b, seqOut);
        }

        int j = rem[bestIdx];
        int Cj = curT + jobs[j].p;
        diff += coeff(j) * ((double)Cj - (double)jobs[j].d);
        curT = Cj;
        order.push_back(j);
        rem.erase(rem.begin() + bestIdx);
    }

    seqOut.clear();
    seqOut.insert(seqOut.end(), onTime.begin(), onTime.end());
    seqOut.insert(seqOut.end(), order.begin(), order.end());

    int tt=0;
    for(int k=0;k<n;k++){
        int j=seqOut[k];
        tt += jobs[j].p;
        if (b[j]==0 && tt>jobs[j].d) return false;
        if (b[j]==1 && tt<=jobs[j].d) return false;
    }
    return true;
}

// Simple local swap search in tardy block
static void improveSeq_TardyLocal(const vector<Job>& jobs, const vector<int>& b, vector<int>& seq, int maxTries, mt19937& rng) {
    int n = (int)jobs.size();
    vector<int> pos(n,-1);
    for(int k=0;k<n;k++) pos[seq[k]] = k;

    int startTardy = n;
    for(int k=0;k<n;k++){
        if (b[seq[k]]==1){ startTardy = k; break; }
    }
    if (startTardy >= n-1) return;

    auto feasible = [&](const vector<int>& s)->bool{
        int t=0;
        for(int k=0;k<n;k++){
            int j=s[k];
            t += jobs[j].p;
            if (b[j]==0 && t>jobs[j].d) return false;
            if (b[j]==1 && t<=jobs[j].d) return false;
        }
        return true;
    };

    SolveInfo best = evalSequence(jobs, seq);
    uniform_int_distribution<int> distK(startTardy, n-1);

    for(int it=0; it<maxTries; ++it){
        int i = distK(rng);
        int j = distK(rng);
        if (i==j) continue;
        if (i>j) swap(i,j);

        vector<int> cand = seq;
        swap(cand[i], cand[j]);

        if (!feasible(cand)) continue;

        SolveInfo ev = evalSequence(jobs, cand);
        if (ev.obj + 1e-9 < best.obj){
            seq.swap(cand);
            best = ev;
        }
    }
}

// Main Heuristic AB improved function
static SolveInfo runHeuristicAB_improved2(const vector<Job>& jobs,
                                          int U_min,
                                          double timeLimit,
                                          int seed = 123,
                                          int multistarts = 60)
{
    SolveInfo best;
    double tStart = nowSec();
    int n = (int)jobs.size();
    BigMData bm = computeBigM(jobs);

    mt19937 rng(seed);
    uniform_int_distribution<int> distJob(0, n-1);

    auto mo = mooresAlgorithm(jobs);
    SolveInfo moEv = evalSequence(jobs, mo.second);
    vector<int> b0 = moEv.z;

    auto repairB = [&](vector<int>& b){
        b = makeFixedUminPatternFromReferenceSeq(jobs, mo.second, U_min);
    };
    repairB(b0);

    auto feasiblePatternQuick = [&](const vector<int>& b)->bool{
        CutPrefix cp;
        return !findViolatedPrefixWithinOnTime(jobs, b, cp);
    };

    auto evalPattern = [&](const vector<int>& b, SolveInfo& out)->bool{
        vector<int> seq;
        if (!buildSeq_HeurSignedTardy(jobs, b, seq)) {
            if (!buildSeq_BlockRepair(jobs, b, seq)) return false;
        }
        out = evalSequence(jobs, seq);
        out.z = b;
        out.seq = seq;
        return true;
    };

    best.feasible = false;
    best.obj = 1e100;
    {
        SolveInfo tmp;
        if (feasiblePatternQuick(b0) && evalPattern(b0, tmp)) {
            improveSeq_TardyLocal(jobs, b0, tmp.seq, 1200, rng);
            tmp = evalSequence(jobs, tmp.seq);
            tmp.z = b0;
            best = tmp;
            best.status = "HeurAB-Init";
        }
    }

    vector<vector<int>> starts;
    starts.reserve(multistarts+1);
    starts.push_back(b0);
    for(int s=0;s<multistarts;s++){
        vector<int> b = b0;
        int swaps = 1 + (s % 2);
        for(int r=0;r<swaps;r++){
            int i=-1,j=-1;
            for(int tries=0;tries<60;tries++){
                int a=distJob(rng), c=distJob(rng);
                if (b[a]==1 && b[c]==0 && !bm.alwaysOnTime[c]) { i=a; j=c; break; }
                if (b[a]==0 && b[c]==1 && !bm.alwaysOnTime[a]) { i=c; j=a; break; }
            }
            if (i!=-1 && j!=-1) { b[i]=0; b[j]=1; }
        }
        repairB(b);
        starts.push_back(b);
    }

    for(auto &bStart : starts){
        if (nowSec() - tStart >= timeLimit) break;
        vector<int> b = bStart;

        SolveInfo cur;
        if (!feasiblePatternQuick(b) || !evalPattern(b, cur)) continue;

        improveSeq_TardyLocal(jobs, b, cur.seq, 800, rng);
        cur = evalSequence(jobs, cur.seq);
        cur.z = b;

        if (!best.feasible || cur.obj < best.obj - 1e-9) {
            best = cur;
            best.status = "HeurAB-Best";
        }
        if(best.obj==0)
            break; //achive the lower bound

        int noImp = 0;
        while (nowSec() - tStart < timeLimit && noImp < 200) {
            double bestCandObj = cur.obj;
            vector<int> bestCandB = b;
            vector<int> bestCandSeq = cur.seq;

            for(int k=0;k<25;k++){
                int i=-1,j=-1;
                for(int tries=0;tries<40;tries++){
                    int a=distJob(rng), c=distJob(rng);
                    if (b[a]==1 && b[c]==0 && !bm.alwaysOnTime[c]) { i=a; j=c; break; }
                    if (b[a]==0 && b[c]==1 && !bm.alwaysOnTime[a]) { i=c; j=a; break; }
                }
                if (i==-1 || j==-1) continue;

                vector<int> candB = b;
                candB[i]=0; candB[j]=1;

                if (!feasiblePatternQuick(candB)) continue;

                SolveInfo cand;
                if (!evalPattern(candB, cand)) continue;

                improveSeq_TardyLocal(jobs, candB, cand.seq, 400, rng);
                cand = evalSequence(jobs, cand.seq);
                cand.z = candB;

                if (cand.obj + 1e-9 < bestCandObj) {
                    bestCandObj = cand.obj;
                    bestCandB = candB;
                    bestCandSeq = cand.seq;
                }
            }

            if (bestCandObj + 1e-9 < cur.obj) {
                b = bestCandB;
                cur.obj = bestCandObj;
                cur.z = b;
                cur.seq = bestCandSeq;
                noImp = 0;

                if (cur.obj + 1e-9 < best.obj) {
                    best = cur;
                    best.status = "HeurAB-Best";
                }
            } else {
                noImp++;
            }
        }
    }

    best.feasible = true;
    best.time = nowSec() - tStart;
    if (best.status == "NA") best.status = "HeurAB";
    return best;
}

static SolveInfo runTwoStageP_exact_withHeuristicWarmStart(const vector<Job>& jobs, SolveInfo heur, int U_min, double UB_eta, double timeLimitTotal, bool useVIinMaster, bool useVI12inSub) {
    
    
    
    SolveInfo best;
    double tStart = nowSec();
    int n = jobs.size();

    // If the heuristic already yields eta = 0, return it immediately
    if (heur.obj == 0) {
        best = heur;
        best.status = "HeuristicWarmStart (Optimal)";
        best.time = nowSec() - tStart;
        return best;
    }

    best = heur;
    best.status = "HeuristicWarmStart";
    
    // Set the initial objective to the upper bound (UB_eta)
    double currentObjective = heur.obj;
    if (currentObjective < 0) currentObjective = UB_eta;

    vector<vector<int>> visitedZ;
    vector<CutPrefix> dynCuts;
    int iters = 0;

    while (true) {
        double elapsed = nowSec() - tStart;
        if (elapsed >= timeLimitTotal) {
            best.time = elapsed;
            best.iters = iters;
            best.status = "TimeLimit";
            return best;
        }

        IloEnv env;
        IloModel master(env);
        IloBoolVarArray z(env, n);
        master.add(IloMinimize(env, 0));  // Objective is initialized

        IloExpr sumz(env);
        for (int j = 0; j < n; j++) sumz += z[j];
        master.add(sumz == U_min);
        sumz.end();

        BigMData bm = computeBigM(jobs);
        for (int j = 0; j < n; j++) if (bm.alwaysOnTime[j]) master.add(z[j] == 0);

        // Apply heuristic as a warm start (initialize z and obj)
        if(iters==0)
        {
            for (int j = 0; j < n; ++j) {
                if (heur.z[j] == 1) {
                    master.add(z[j] == 1); // Set the heuristic z values
                } else {
                    master.add(z[j] == 0);
                }
            }
        }

        if (useVIinMaster) {
                  VIFlags vf;
                  // In master, we use VI3..VI5; VI1/VI2 are position-based
                  vf.VI1_prefix_S_lb = false;
                  vf.VI2_sym_identical = false;
                  addVI_Zonly(env, master, jobs, z, vf);
              }

              // dynamic feasibility cuts (only derived from *infeasible* subproblems)
              addDynamicFeasCutsToMaster(env, master, jobs, z, dynCuts);

              // no-good cuts
              if (!visitedZ.empty()) addNoGoodCutsToMaster(env, master, z, visitedZ);


        try {
            IloCplex cplex(master);
            cplex.setParam(IloCplex::Param::Threads, 1); // Multi-threading for better performance
            cplex.setParam(IloCplex::Param::MIP::Display, 0);
            cplex.setOut(env.getNullStream());
            double remain = max(1.0, timeLimitTotal - elapsed);
            cplex.setParam(IloCplex::Param::TimeLimit, remain);

            bool ok = cplex.solve();
            iters++;

            if (!ok || !(cplex.getStatus() == IloAlgorithm::Optimal || cplex.getStatus() == IloAlgorithm::Feasible)) {
                best.time = nowSec() - tStart;
                best.iters = iters;
                best.status = "MasterExhausted(NoSolve)";
                env.end();
                return best;
            }

            vector<int> b(n, 0);
            for (int j = 0; j < n; j++) b[j] = (cplex.getValue(z[j]) > 0.5 ? 1 : 0);
            visitedZ.push_back(b);
            env.end();

            double elapsed2 = nowSec() - tStart;
            double remain2 = max(1.0, timeLimitTotal - elapsed2);
            SolveInfo sub = solveSubproblem_MIP_P_fixedZ(jobs, b, best.obj, remain2, useVI12inSub);

            if (sub.feasible) {
                if (sub.obj < best.obj - 1e-9) {
                    best = sub;
                    best.status = "TwoStage(P) best";
                }
            } else {
                CutPrefix cp;
                if (findViolatedPrefixWithinOnTime(jobs, b, cp)) {
                    CutPrefix c1 = cp; c1.type = 1; dynCuts.push_back(c1);
                    CutPrefix c3 = cp; c3.type = 3; dynCuts.push_back(c3);
                    CutPrefix c4 = cp; c4.type = 4; dynCuts.push_back(c4);
                }
            }

        } catch (IloException& e) {
            cerr << "CPLEX exception: " << e << endl;
            best.status = "CPLEX_Exception";
            best.feasible = false;
        }
    }

    return best;
}





// ============================ Logging ============================
static string vecToStr(const vector<int>& v) {
    ostringstream oss;
    for (size_t i = 0; i < v.size(); i++) {
        if (i) oss << " ";
        oss << v[i];
    }
    return oss.str();
}

static void writeMethodLog(ofstream& f, const string& name, const SolveInfo& s) {
    f << "[" << name << "]\n";
    f << "status=" << s.status << "\n";
    f << "feasible=" << (s.feasible ? 1 : 0) << "\n";
    f << fixed << setprecision(6);
    f << "eta=" << s.obj << "\n";
    f << "time=" << s.time << "\n";
    f << "gap=" << s.gap << "\n";
    f << "iters=" << s.iters << "\n";
    f << "cuts=" << s.cuts << "\n";
    if (!s.z.empty()) {
        f << "tardy_count=" << countTardy(s.z) << "\n";
        f << "z=" << vecToStr(s.z) << "\n";
    }
    if (!s.seq.empty()) f << "seq=" << vecToStr(s.seq) << "\n";
    f << "\n";
}


// ============================ Main ============================
static string oneDec(double x) {
    ostringstream oss;
    oss << fixed << setprecision(1) << x;
    return oss.str();
}

int main() {
    cout << "=====================================================\n";
    cout << "Pareto-style comparison over tardy-count levels:\n";
    cout << "  methods: MIP-P+VI, Heuristic AB, CP (warm-started)\n";
    cout << "  tardy count levels: U_min, U_min+1, ..., U_min+5\n";
    cout << "=====================================================\n";

    const string basePath = "/Users/shijinwang/Desktop/Pareto";
    system(("mkdir -p \"" + basePath + "\"").c_str());
    cout << "Output directory: " << basePath << "\n";

    const vector<int> n_values = {20, 30};
    const int instances_per_n = 10;
    const double TL = 3600.0;
    const vector<double> TF_values = {0.6, 0.8, 1.0};
    const vector<double> RDD_values = {0.6, 0.8, 1.0};
    const int maxExtraTardy = 5;
    const int seedBase = 12345;

    string csvPath = basePath + "/results_summary.csv";
    ofstream csv(csvPath.c_str());
    csv << "TF,RDD,n,inst,seed,base_U_min,target_tardy,delta,ub_eta,"
        << "heur_status,heur_eta,heur_time,heur_wTA,heur_wTB,heur_tardy_count,"
        << "mippvi_status,mippvi_eta,mippvi_time,mippvi_gap,mippvi_wTA,mippvi_wTB,mippvi_tardy_count,"
        << "cpws_status,cpws_eta,cpws_time,cpws_gap,cpws_iters,cpws_cuts,cpws_wTA,cpws_wTB,cpws_tardy_count,"
        << "best_method,best_eta\n";

    for (double TF : TF_values) {
        for (double RDD : RDD_values) {
            string comboPath = basePath + "/TF=" + oneDec(TF) + ",RDD=" + oneDec(RDD);
            system(("mkdir -p \"" + comboPath + "\"").c_str());

            cout << "\n=====================================================\n";
            cout << "TF=" << TF << ", RDD=" << RDD << "\n";
            cout << "=====================================================\n";

            for (int n : n_values) {
                cout << "\n==== n=" << n << " ====" << "\n";

                for (int inst = 0; inst < instances_per_n; ++inst) {
                    int seed = seedBase + int(std::lround(TF * 1000.0)) * 100000
                                       + int(std::lround(RDD * 1000.0)) * 1000
                                       + n * 100 + inst;

                    vector<Job> jobs = generateInstance_TF_RDD(n, seed, TF, RDD);
                    string instPath = comboPath + "/instance_n" + to_string(n) + "_i" + to_string(inst) + ".csv";
                    saveInstanceCSV(instPath, jobs);

                    auto mo = mooresAlgorithm(jobs);
                    int baseU = mo.first;

                    cout << "\n-- instance " << inst << " (seed=" << seed << ", base_U_min=" << baseU << ") --\n";

                    for (int delta = 0; delta <= maxExtraTardy; ++delta) {
                        int targetU = baseU + delta;
                        double UB_eta = computeEtaUpperBound(jobs);

                        cout << "  target tardy count = " << targetU << "\n";

                        string logPath = comboPath + "/detail_n" + to_string(n)
                                       + "_i" + to_string(inst)
                                       + "_u" + to_string(targetU) + ".txt";
                        ofstream lf(logPath.c_str());
                        lf << "TF=" << TF << ", RDD=" << RDD << "\n";
                        lf << "n=" << n << ", inst=" << inst << ", seed=" << seed << "\n";
                        lf << "base_U_min=" << baseU << "\n";
                        lf << "target_tardy=" << targetU << "\n";
                        lf << "delta=" << delta << "\n\n";

                        double heurTL = min(60.0, TL);
                        SolveInfo heur = runHeuristicAB_improved2(jobs, targetU, heurTL,
                                                                  seedBase + inst + n * 7 + delta * 97, 80);
                        if (heur.feasible) UB_eta = min(UB_eta, max(0.0, heur.obj));
                        cout << "    Heuristic:    status=" << heur.status
                             << " eta=" << heur.obj << " time=" << heur.time << "\n";
                        writeMethodLog(lf, "HeuristicAB", heur);

                        SolveInfo mippvi = solveMIP_P(jobs, targetU, UB_eta, TL, true);
                        cout << "    MIP-P+VI:     status=" << mippvi.status
                             << " eta=" << mippvi.obj << " time=" << mippvi.time
                             << " gap=" << mippvi.gap << "\n";
                        writeMethodLog(lf, "MIP-P+VI", mippvi);

                        SolveInfo cpws;
                        if (heur.feasible) {
                            cpws = runTwoStageP_exact_withHeuristicWarmStart(jobs, heur, targetU, UB_eta, TL, true, true);
                        } else {
                            cpws = runTwoStageP_exact(jobs, targetU, UB_eta, TL, true, true);
                            cpws.status = string("NoWarmStart-") + cpws.status;
                        }
                        cout << "    CP-warm:      status=" << cpws.status
                             << " eta=" << cpws.obj << " time=" << cpws.time
                             << " iters=" << cpws.iters << " cuts=" << cpws.cuts << "\n";
                        writeMethodLog(lf, "CPWarmStarted", cpws);

                        vector<pair<string, double> > cand;
                        if (mippvi.feasible && mippvi.obj >= -0.5) cand.push_back(make_pair(string("MIP-P+VI"), mippvi.obj));
                        if (heur.feasible && heur.obj >= -0.5) cand.push_back(make_pair(string("HeuristicAB"), heur.obj));
                        if (cpws.feasible && cpws.obj >= -0.5) cand.push_back(make_pair(string("CPWarmStarted"), cpws.obj));

                        string bestMethod = "NA";
                        double bestEta = -1.0;
                        if (!cand.empty()) {
                            pair<string,double> best = cand[0];
                            for (size_t t = 1; t < cand.size(); ++t) {
                                if (cand[t].second < best.second) best = cand[t];
                            }
                            bestMethod = best.first;
                            bestEta = best.second;
                        }

                        lf << "[Comparison]\n";
                        lf << "best_method=" << bestMethod << "\n";
                        lf << fixed << setprecision(6) << "best_eta=" << bestEta << "\n";
                        lf.close();

                        csv << fixed << setprecision(1)
                            << TF << "," << RDD << ","
                            << setprecision(0) << n << "," << inst << "," << seed << ","
                            << baseU << "," << targetU << "," << delta << ","
                            << setprecision(6) << UB_eta << ","
                            << heur.status << "," << heur.obj << "," << heur.time << "," << heur.wTA << "," << heur.wTB << "," << countTardy(heur.z) << ","
                            << mippvi.status << "," << mippvi.obj << "," << mippvi.time << "," << mippvi.gap << "," << mippvi.wTA << "," << mippvi.wTB << "," << countTardy(mippvi.z) << ","
                            << cpws.status << "," << cpws.obj << "," << cpws.time << "," << cpws.gap << "," << cpws.iters << "," << cpws.cuts << "," << cpws.wTA << "," << cpws.wTB << "," << countTardy(cpws.z) << ","
                            << bestMethod << "," << bestEta << "\n";
                    }
                }
            }
        }
    }

    csv.close();
    cout << "\nDONE. Summary CSV:\n  " << csvPath << "\n";
    return 0;
}
